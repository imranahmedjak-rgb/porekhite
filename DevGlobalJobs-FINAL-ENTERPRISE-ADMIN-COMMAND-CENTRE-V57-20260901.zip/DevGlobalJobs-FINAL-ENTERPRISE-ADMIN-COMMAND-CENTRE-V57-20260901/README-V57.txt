DEV GLOBAL JOBS V57 · ENTERPRISE ADMINISTRATION COMMAND CENTRE

Purpose
- Presentation-only enterprise upgrade of the Dev Global Jobs administration workspace.
- Designed from the actual Admin screenshots and existing V45/V46/V49/V51/V56 control surfaces.

Scope
- Adds dgj-v57-admin-enterprise.css and dgj-v57-admin-enterprise.js.
- Updates only public index wiring to load those assets with v=57.0.0.
- Does NOT replace dist/index.cjs or any backend module.
- Does NOT change PostgreSQL, PM2, recruitment logic, payments, Easy Apply, email segmentation, Google Jobs, sitemap, Youth, social, brand or service worker.

Admin experience
- Cohesive dark enterprise navigation + clean light operational canvas.
- Grouped navigation: Command, Publishing, Talent & Recruitment, Employer & Commercial, Infrastructure.
- Executive command header with direct access to Recruitment Centre, Employer Accounts, Revenue and All Jobs when those controls are available.
- Full-width large-screen layout up to 1600px+ displays with responsive density.
- Premium tables, forms, cards, filters and status surfaces.
- Consistent Promotion Centre, Employer Accounts and Recruitment Centre full-screen consoles.
- Empty blank containers with artificial large heights are collapsed only when truly empty.
- Fixed Growth & CRM/share/bookmark clutter is hidden inside Admin only.
- Mobile, tablet and standalone PWA safeguards.

Safety
- Exact successful V56-FIXED production baseline required.
- Private rollback backup before any mutation.
- Only 3 frontend files are in the payload.
- Deployment is atomic and does not reload PM2.
