#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"; PAYLOAD="$BASE/payload"
fail(){ echo "FAIL: $*"; exit 1; }
for c in node grep find sha256sum; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
JS="$PAYLOAD/dist/public/assets/dgj-v57-admin-enterprise.js"
CSS="$PAYLOAD/dist/public/assets/dgj-v57-admin-enterprise.css"
IDX="$PAYLOAD/dist/public/index.html"
[ -f "$JS" ] && [ -f "$CSS" ] && [ -f "$IDX" ] || fail "V57 payload incomplete"
COUNT=$(find "$PAYLOAD" -type f | wc -l | tr -d ' ')
[ "$COUNT" = 3 ] || fail "V57 payload must contain exactly 3 frontend files (found $COUNT)"
node --check "$JS" >/dev/null || fail "V57 JS syntax invalid"
grep -Fq "if(!/^\\/admin(?:\\/|$)/.test(location.pathname))return;" "$JS" || fail "Admin-only route guard missing"
grep -Fq "dgj57-command-header" "$JS" || fail "Enterprise command header missing"
grep -Fq "dgj57-admin-sidebar" "$JS" || fail "Sidebar enhancement missing"
grep -Fq "dgj57-enterprise-overlay" "$JS" || fail "Operational console enhancement missing"
grep -Fq "dgj57-empty-collapse" "$JS" || fail "Empty-space control missing"
grep -Fq "Applications & hiring pipeline" "$JS" || fail "Recruitment quick access missing"
grep -Fq "Employer Accounts" "$JS" || fail "Employer Accounts quick access missing"
grep -Fq "Promotion Centre" "$CSS" || true
grep -Fq "@media(max-width:760px)" "$CSS" || fail "Mobile admin breakpoint missing"
grep -Fq "@media(display-mode:standalone)" "$CSS" || fail "PWA standalone safeguard missing"
grep -Fq "dgj57-enterprise-overlay .dgj46-admin-table" "$CSS" || fail "Employer Accounts table styling missing"
grep -Fq "dgj57-enterprise-overlay .dgj51-admin-table" "$CSS" || fail "Recruitment Centre table styling missing"
grep -Fq 'dgj-v57-admin-enterprise.css?v=57.0.0' "$IDX" || fail "V57 CSS index wiring missing"
grep -Fq 'dgj-v57-admin-enterprise.js?v=57.0.0' "$IDX" || fail "V57 JS index wiring missing"
[ "$(grep -o 'dgj-v57-admin-enterprise.css?v=57.0.0' "$IDX" | wc -l)" = 1 ] || fail "V57 CSS wired more than once"
[ "$(grep -o 'dgj-v57-admin-enterprise.js?v=57.0.0' "$IDX" | wc -l)" = 1 ] || fail "V57 JS wired more than once"
! grep -Fq 'insertBefore' "$JS" || fail "V57 JS contains prohibited insertBefore DOM pattern"
! find "$PAYLOAD" -type f \( -name '*.cjs' -o -name '*.sql' -o -name '*.env' -o -name 'sw.js' \) | grep -q . || fail "V57 must not contain backend/database/service-worker files"
echo "PASS: V57 enterprise Admin Command Centre, full-width sections, operational consoles, responsive tables and empty-space controls verified."
