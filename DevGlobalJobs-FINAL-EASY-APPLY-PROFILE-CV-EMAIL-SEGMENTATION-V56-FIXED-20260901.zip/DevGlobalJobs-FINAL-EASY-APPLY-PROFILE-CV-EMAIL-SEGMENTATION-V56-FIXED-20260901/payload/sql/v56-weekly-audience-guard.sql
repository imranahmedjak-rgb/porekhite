\set ON_ERROR_STOP on

BEGIN;

DO $preflight$
DECLARE
  missing text[] := ARRAY[]::text[];
BEGIN
  IF to_regclass('public.dgj_marketing_contacts') IS NULL THEN
    RAISE EXCEPTION 'dgj_marketing_contacts is missing';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='dgj_marketing_contacts' AND column_name='id') THEN missing:=array_append(missing,'id'); END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='dgj_marketing_contacts' AND column_name='email') THEN missing:=array_append(missing,'email'); END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='dgj_marketing_contacts' AND column_name='audience') THEN missing:=array_append(missing,'audience'); END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='dgj_marketing_contacts' AND column_name='active') THEN missing:=array_append(missing,'active'); END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='dgj_marketing_contacts' AND column_name='updated_at') THEN missing:=array_append(missing,'updated_at'); END IF;
  IF cardinality(missing)>0 THEN RAISE EXCEPTION 'dgj_marketing_contacts missing columns: %',array_to_string(missing,','); END IF;
END
$preflight$;

CREATE OR REPLACE FUNCTION public.dgj_v56_enforce_weekly_audience()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $fn$
BEGIN
  NEW.email := lower(btrim(NEW.email));

  IF NEW.audience='job_seeker' AND NEW.active=true
     AND EXISTS (
       SELECT 1 FROM public.dgj_marketing_contacts e
       WHERE lower(e.email)=lower(NEW.email)
         AND e.audience='employer'
         AND e.active=true
         AND e.id<>COALESCE(NEW.id,0)
     ) THEN
    NEW.active=false;

  ELSIF NEW.audience='employer' AND NEW.active=true THEN
    UPDATE public.dgj_marketing_contacts
       SET active=false,updated_at=NOW()
     WHERE lower(email)=lower(NEW.email)
       AND audience='job_seeker'
       AND active=true
       AND id<>COALESCE(NEW.id,0);

    IF to_regclass('public.dgj_email_queue') IS NOT NULL THEN
      UPDATE public.dgj_email_queue
         SET status='suppressed',last_error='Employer-only weekly audience'
       WHERE status IN ('queued','retry','processing')
         AND contact_id IN (
           SELECT id FROM public.dgj_marketing_contacts
           WHERE lower(email)=lower(NEW.email) AND audience='job_seeker'
         );
    END IF;
  END IF;

  RETURN NEW;
END
$fn$;

REVOKE ALL ON FUNCTION public.dgj_v56_enforce_weekly_audience() FROM PUBLIC;

DROP TRIGGER IF EXISTS dgj_v56_weekly_audience_guard ON public.dgj_marketing_contacts;
CREATE TRIGGER dgj_v56_weekly_audience_guard
BEFORE INSERT OR UPDATE OF email,audience,active
ON public.dgj_marketing_contacts
FOR EACH ROW
EXECUTE FUNCTION public.dgj_v56_enforce_weekly_audience();

-- Immediately reconcile existing dual-audience addresses. Employer precedence
-- applies only to weekly marketing audiences; transactional candidate/employer
-- notifications are not affected.
UPDATE public.dgj_marketing_contacts js
   SET active=false,updated_at=NOW()
 WHERE js.audience='job_seeker'
   AND js.active=true
   AND EXISTS (
     SELECT 1 FROM public.dgj_marketing_contacts e
     WHERE lower(e.email)=lower(js.email)
       AND e.audience='employer'
       AND e.active=true
   );

DO $queue$
BEGIN
  IF to_regclass('public.dgj_email_queue') IS NOT NULL THEN
    UPDATE public.dgj_email_queue q
       SET status='suppressed',last_error='Employer-only weekly audience'
     WHERE q.status IN ('queued','retry','processing')
       AND q.contact_id IN (
         SELECT js.id
         FROM public.dgj_marketing_contacts js
         WHERE js.audience='job_seeker'
           AND js.active=false
           AND EXISTS (
             SELECT 1 FROM public.dgj_marketing_contacts e
             WHERE lower(e.email)=lower(js.email)
               AND e.audience='employer'
               AND e.active=true
           )
       );
  END IF;
END
$queue$;

COMMIT;
