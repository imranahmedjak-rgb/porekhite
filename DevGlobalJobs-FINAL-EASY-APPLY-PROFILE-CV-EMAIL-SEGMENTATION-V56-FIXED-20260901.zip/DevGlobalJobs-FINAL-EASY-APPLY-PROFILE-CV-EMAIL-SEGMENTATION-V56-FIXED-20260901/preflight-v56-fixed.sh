#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; PAYLOAD="$HERE/payload"
fail(){ echo "FAIL: $*" >&2; exit 1; }
for c in sha256sum node grep bash; do command -v "$c" >/dev/null 2>&1 || fail "Required command missing: $c"; done
(cd "$PAYLOAD" && sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt" >/dev/null) || fail "Payload checksum mismatch."
node --check "$PAYLOAD/dist/dgj-v51-recruitment.cjs" >/dev/null || fail "V56-FIXED recruitment backend syntax invalid."
node --check "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" >/dev/null || fail "V56 Employer frontend syntax invalid."
node --check "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" >/dev/null || fail "V56 candidate frontend syntax invalid."

grep -Fq "const V56_VERSION='56.0.1'" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "V56-FIXED module version missing."
grep -Fq "const PROFILE_MIN_SCORE=80" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "80% server profile gate missing."
grep -Fq "/api/v56/candidate/profile-readiness" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Profile readiness API missing."
grep -Fq "candidateProfileReadiness" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Server profile scoring missing."
grep -Fq "cv_source" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "CV source persistence missing."
grep -Fq "cv_format" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "CV format persistence missing."
grep -Fq "candidate_confirmation_status" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Candidate confirmation tracking missing."
grep -Fq "Application confirmed –" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Candidate confirmation email missing."

# The application role must never touch Growth CRM trigger DDL during PM2 startup.
! grep -Fq "dgj_marketing_contacts" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Recruitment startup still touches protected Growth CRM table."
! grep -Fq "CREATE TRIGGER" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Recruitment startup still creates a DB trigger."

grep -Fq "SECURITY DEFINER" "$PAYLOAD/sql/v56-weekly-audience-guard.sql" || fail "Privileged audience guard must be SECURITY DEFINER."
grep -Fq "SET search_path = pg_catalog, public" "$PAYLOAD/sql/v56-weekly-audience-guard.sql" || fail "Audience guard fixed search_path missing."
grep -Fq "dgj_v56_weekly_audience_guard" "$PAYLOAD/sql/v56-weekly-audience-guard.sql" || fail "Weekly audience trigger SQL missing."
grep -Fq "Employer-only weekly audience" "$PAYLOAD/sql/v56-weekly-audience-guard.sql" || fail "Queued seeker suppression missing."
grep -Fq "BEGIN;" "$PAYLOAD/sql/v56-weekly-audience-guard.sql" || fail "Audience migration transaction start missing."
grep -Fq "COMMIT;" "$PAYLOAD/sql/v56-weekly-audience-guard.sql" || fail "Audience migration transaction commit missing."

grep -Fq "Apply with Profile CV" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Profile CV Easy Apply path missing."
grep -Fq "Apply with Uploaded CV" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Uploaded CV Easy Apply path missing."
for x in "British CV" "Europass CV" "Middle East CV" "New Zealand CV"; do grep -Fq "$x" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "$x option missing"; done
grep -Fq "window.jspdf" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Profile PDF generator missing."
grep -Fq "Complete My Profile" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Profile completion CTA missing."
grep -Fq "Profile quality" "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" || fail "Employer profile quality display missing."
grep -Fq '/assets/dgj-v51-employer.js?v=56.0.1' "$PAYLOAD/dist/public/index.html" || fail "Employer V56-FIXED cache bust missing."
grep -Fq '/assets/dgj-v51-recruitment.js?v=56.0.1' "$PAYLOAD/dist/public/index.html" || fail "Candidate V56-FIXED cache bust missing."
grep -Fq '/assets/dgj-v51-recruitment.css?v=56.0.1' "$PAYLOAD/dist/public/index.html" || fail "CSS V56-FIXED cache bust missing."
grep -Fq "const RETENTION_DAYS=180" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "180-day retention changed."
grep -Fq "Applications delivered through Easy Apply via Email cannot be withdrawn" "$PAYLOAD/dist/dgj-v51-recruitment.cjs" || fail "Email no-withdraw rule changed."
! grep -Rqs "insertBefore" "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" || fail "Unsafe insertBefore found."
[ ! -f "$PAYLOAD/dist/index.cjs" ] || fail "V56-FIXED must not replace main runtime."
[ ! -f "$PAYLOAD/dist/dgj-v45-commercial.cjs" ] || fail "V56-FIXED must not replace V45 backend."
[ ! -f "$PAYLOAD/dist/dgj-v46-employer.cjs" ] || fail "V56-FIXED must not replace V46 backend."
[ ! -f "$PAYLOAD/dist/public/assets/dgj-v49-premium.js" ] || fail "V56-FIXED must not replace V49 premium JS."
! grep -Rqs "BEGIN PRIVATE KEY" "$PAYLOAD" || fail "Private key material detected."

bash -n "$HERE/deploy-v56-fixed-quality-safe.sh" || fail "V56-FIXED deploy script syntax invalid."
! grep -Fq 'local src="$1" dst="$2"' "$HERE/deploy-v56-fixed-quality-safe.sh" || fail "Unsafe set -u local assignment detected."
! grep -Fq ' | grep -Fq ' "$HERE/deploy-v56-fixed-quality-safe.sh" || fail "Unsafe curl|grep -q pipefail pattern detected."

# Route registration smoke test with a non-persistent mock pool. This specifically
# proves install() no longer needs Growth CRM table ownership/trigger privilege.
node - "$PAYLOAD/dist/dgj-v51-recruitment.cjs" <<'NODE'
const file=process.argv[2],routes=[],sql=[];
const rec=m=>(...a)=>routes.push([m,a[0]]);
const app={get:rec('GET'),post:rec('POST'),put:rec('PUT'),delete:rec('DELETE'),patch:rec('PATCH'),use:()=>{}};
const mkclient=()=>({query:async(q)=>{sql.push(String(q));return String(q).includes('pg_try_advisory_lock')?{rows:[{locked:false}],rowCount:1}:{rows:[],rowCount:0}},release(){}});
const pool={query:async(q)=>{sql.push(String(q));return {rows:[],rowCount:0}},connect:async()=>mkclient()};
(async()=>{const mod=require(file);const out=await mod.install({app,pool,requireAdmin:(q,r,n)=>n&&n(),dgjEvent:async()=>{}});if(out.v56Version!=='56.0.1')throw new Error('V56-FIXED version missing');for(const p of ['/api/v56/config','/api/v56/candidate/profile-readiness','/api/v51/jobs/:id/easy-apply','/api/v51/candidate/applications','/api/v51/employer/applications'])if(!routes.some(r=>r[1]===p))throw new Error('Missing route '+p);if(sql.some(q=>/dgj_marketing_contacts|CREATE\s+TRIGGER/i.test(q)))throw new Error('Install touched protected Growth CRM DDL');})().catch(e=>{console.error(e);process.exit(1)});
NODE

echo "PASS: V56-FIXED startup privilege isolation, Easy Apply profile quality, Profile CV and candidate email regression preflight complete."
