Dev Global Jobs V56-FIXED (56.0.1)

Production fix for the V56 startup failure caused by the application database role
attempting to CREATE TRIGGER on dgj_marketing_contacts.

The recruitment module no longer touches Growth CRM marketing tables during PM2
startup. Employer-precedence weekly audience segmentation is installed separately
by the root deployment script using the local PostgreSQL superuser and a
SECURITY DEFINER trigger with a fixed search_path.

Preserved V56 features:
- Easy Apply requires server-verified 80% candidate profile completion.
- Candidate chooses Profile CV or Uploaded CV after one public Easy Apply button.
- Profile CV formats: British, Europass, Middle East, New Zealand.
- Candidate receives a position-specific application confirmation email.
- Employer weekly audience takes precedence over job-seeker weekly audience for
  the same email address.
- V55 zero-flash/performance, V51 ATS/180-day retention, V45 commercial system,
  Google Jobs, sitemap, Youth, social, brand and PWA architecture remain protected.
