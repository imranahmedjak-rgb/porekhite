DEV GLOBAL JOBS V56-FIXED · 56.0.1

Use only:
  ./preflight-v56-fixed.sh
  ./deploy-v56-fixed-quality-safe.sh

Why FIXED exists
----------------
The first V56 package passed offline validation but failed on production startup
because the normal application PostgreSQL role does not own dgj_marketing_contacts
and therefore cannot CREATE TRIGGER on that Growth CRM table. Production safely
rolled back to V55.

V56-FIXED removes all Growth CRM trigger DDL from the recruitment module startup.
The app starts using its normal least-privilege DB role. Only after backend and
frontend validation pass, the root deployment script installs the weekly audience
guard transactionally through the local PostgreSQL superuser.

Feature contract
----------------
1. Employer weekly audience has precedence over same-email job-seeker weekly audience.
2. Candidate Easy Apply requires server-verified profile score >= 80%.
3. One Easy Apply button opens two candidate CV choices:
   - Apply with Profile CV
   - Apply with Uploaded CV
4. Profile CV formats: British, Europass, Middle East, New Zealand.
5. Successful Easy Apply sends the candidate a position-specific confirmation email.
6. Employer sees CV source/format and profile quality in Applications.
7. Easy Apply via Email remains non-withdrawable in DGJ.
8. V51 ATS, candidate tracking, reports, private CV storage and 180-day retention remain.
9. V55 zero-flash/performance and V45 commercial architecture remain protected.
10. Main runtime, Google Jobs, sitemap architecture, Youth, social, brand and PWA are not replaced.
