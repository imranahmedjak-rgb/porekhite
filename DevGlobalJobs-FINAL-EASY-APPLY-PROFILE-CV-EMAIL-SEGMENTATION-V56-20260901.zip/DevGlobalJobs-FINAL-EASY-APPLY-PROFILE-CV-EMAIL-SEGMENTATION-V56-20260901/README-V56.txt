Dev Global Jobs V56 — Candidate Quality + Profile CV + Role Email Segmentation

Scope:
- Employers receive employer weekly audience emails only; active employer email suppresses job-seeker weekly audience for the same address.
- Easy Apply requires server-verified 80% candidate profile completion.
- One public Easy Apply button opens two candidate CV paths: Profile CV or Uploaded CV.
- Profile CV supports British, Europass, Middle East and New Zealand formats generated from the candidate profile.
- Candidate receives premium application-confirmation email with position, organisation, application ID, CV source and tracking CTA.
- Application stores CV source/format/profile score and exposes them to authorised employer/admin reports.
- V51 ATS, 180-day retention, V55 zero-flash employer workspace, V45 payments/Boost and protected SEO/PWA architecture are preserved.

Deployment requires PM2 reload because the V51 recruitment backend module is upgraded in-place.
