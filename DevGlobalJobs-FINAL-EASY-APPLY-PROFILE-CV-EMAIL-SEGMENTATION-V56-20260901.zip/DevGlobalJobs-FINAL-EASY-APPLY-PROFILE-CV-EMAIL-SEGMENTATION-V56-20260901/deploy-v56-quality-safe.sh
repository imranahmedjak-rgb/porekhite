#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"; DIST="$APP/dist"; PUBLIC="$DIST/public"; ASSETS="$PUBLIC/assets"
BASE="$(cd "$(dirname "$0")" && pwd)"; PAYLOAD="$BASE/payload"
sha(){ sha256sum "$1" | awk '{print $1}'; }
fail(){ echo; echo "SAFE STOP: $*"; exit 1; }
MUTATED=0; BACKUP=""
rollback(){
  if [ "$MUTATED" = 1 ] && [ -n "$BACKUP" ] && [ -d "$BACKUP" ]; then
    echo "ROLLBACK: restoring exact pre-V56 V55 files..."
    cp -a "$BACKUP/dgj-v51-recruitment.cjs" "$DIST/dgj-v51-recruitment.cjs"
    cp -a "$BACKUP/dgj-v51-employer.js" "$ASSETS/dgj-v51-employer.js"
    cp -a "$BACKUP/dgj-v51-recruitment.js" "$ASSETS/dgj-v51-recruitment.js"
    cp -a "$BACKUP/dgj-v51-recruitment.css" "$ASSETS/dgj-v51-recruitment.css"
    cp -a "$BACKUP/index.html" "$PUBLIC/index.html"
    pm2 reload devglobaljobs --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE. Additive V56 application columns/email-audience guard may remain in PostgreSQL; restored V55 runtime ignores V56 application fields."
  fi
}
trap 'rc=$?; if [ $rc -ne 0 ]; then rollback; fi; exit $rc' EXIT

# Exact successful V55 production baseline.
SERVER="754afef80c982fd75e6373d839893858a85f42909589da5ffd29d59c2fdbcd0c"
V45B="604bc9cdc6f60ec989bf9582558dbe5b470018e3e1ffb631a9866763d8859dfe"
V46B="bc5c4f4088cc434aabe5acfba0c9b521228330775799c55c2e941a95f05b205e"
V55REC="904fa113528a1cde41dcaade4bbca5dc40083390f1e800bc490279f211e6235e"
V55EMP="5abc7280f90619bd5d9a8aae92bfc4385dea88877891d1369b92bd85f4cd95c9"
V55V49="9df668535f6876ba727c17cc85eabf33f9004f114b4109cc990b129c810e841d"
V55RECJS="b57bc6b109750780caae871fa6f0ecb70f5d3cd399a539ec054678dbfca840b8"
V55CSS="b2a741b913b268e160ac6a5dc1eafcaa64bc8b5d5cfda68dbb40ae3134b18bed"
V55IDX="74943c2276026e1f401d5201a6e9a548c037717c94e4e5cc9cdf96ab8abffb3b"
V45UI="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
V45CSS="cd3038190e9fc212058fd53bdf506b6bd28661764fdb083605e589d54819dfe7"
V46CSS="d541842ee81e1b7e9256a32bff9654709d1ff6c78edae7fb2c91a9762a195b9c"
V49CSS="5929d5a9edb36e5670dadf0511508e945751b510dbb20fead09116f5e1c41e2f"
YOUTH="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
GOOGLE="efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6"
SOCIAL="528878c345ddf89bde59041513d2b406fb1c8bcb786ee9874413247a6a6cbd92"
CONTRACT="00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4"
SW="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"
NEWREC="b1a14c447d6b15e5add52c8b4de2ae9a173a03fe4309c76bc11986c4e7015072"; NEWEMP="ccb98c520e01e5d169d1dd25c97eb245897f78ecc75c16c9fedb7f8b0cb05323"; NEWJS="00f62b1ac36d7b3acd7aac5ad2b92bbcf6306c0bb923e047e178516f2d56cb76"; NEWCSS="3a469af1f44d30050338510f2186cda9f2f4e2efaab511bf55af3d4d3725ec04"; NEWIDX="c48dda09138e2339a1d72052a5ca4c5ea997518ebe38b878ce8881a5673a7fc3"

echo "============================================================"
echo "DEV GLOBAL JOBS V56"
echo "80% PROFILE QUALITY + PROFILE CV + CANDIDATE CONFIRMATION"
echo "EMPLOYER-ONLY WEEKLY EMAIL SEGMENTATION"
echo "============================================================"

echo "1/9 EXACT V55 BASELINE + LIVE HEALTH"
[ "$(sha "$DIST/index.cjs")" = "$SERVER" ] || fail "main runtime differs"
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$V45B" ] || fail "V45 backend differs"
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$V46B" ] || fail "V46 backend differs"
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$V55REC" ] || fail "V51 recruitment backend is not exact V55 baseline"
[ "$(sha "$ASSETS/dgj-v51-employer.js")" = "$V55EMP" ] || fail "Employer JS is not exact V55 baseline"
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$V55V49" ] || fail "V49 premium JS differs"
[ "$(sha "$ASSETS/dgj-v51-recruitment.js")" = "$V55RECJS" ] || fail "Recruitment JS is not exact V55 baseline"
[ "$(sha "$ASSETS/dgj-v51-recruitment.css")" = "$V55CSS" ] || fail "Recruitment CSS is not exact V55 baseline"
[ "$(sha "$PUBLIC/index.html")" = "$V55IDX" ] || fail "index is not exact V55 baseline"
curl -fsS --max-time 15 http://127.0.0.1:8080/api/v51/config -o /tmp/dgj-v56-before.json || fail "V51 backend unhealthy"
echo "PASS: exact V55 production baseline healthy."

echo "2/9 PACKAGE + OFFLINE REGRESSION PREFLIGHT"
"$BASE/preflight-v56.sh" || fail "V56 preflight failed"
(cd "$PAYLOAD" && sha256sum -c "$BASE/PAYLOAD-SHA256SUMS.txt" >/dev/null) || fail "V56 payload checksum failed"
echo "PASS: V56 package integrity and feature gates verified."

echo "3/9 PROTECTED ARCHITECTURE BEFORE MUTATION"
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$V45UI" ] || fail "V45 commercial UI differs"
[ "$(sha "$ASSETS/dgj-v45-commercial.css")" = "$V45CSS" ] || fail "V45 CSS differs"
[ "$(sha "$ASSETS/dgj-v46-employer.css")" = "$V46CSS" ] || fail "V46 CSS differs"
[ "$(sha "$ASSETS/dgj-v49-premium.css")" = "$V49CSS" ] || fail "V49 CSS differs"
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$YOUTH" ] || fail "Youth differs"
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$GOOGLE" ] || fail "Google Jobs differs"
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$SOCIAL" ] || fail "social image differs"
[ "$(sha "$PUBLIC/brand-contract.json")" = "$CONTRACT" ] || fail "brand contract differs"
[ "$(sha "$PUBLIC/sw.js")" = "$SW" ] || fail "service worker differs"
echo "PASS: commercial/SEO/Youth/social/brand/PWA protected."

echo "4/9 PRIVATE ROLLBACK BACKUP"
BACKUP="/var/backups/devglobaljobs-v56-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BACKUP"
cp -a "$DIST/dgj-v51-recruitment.cjs" "$BACKUP/"
cp -a "$ASSETS/dgj-v51-employer.js" "$BACKUP/"
cp -a "$ASSETS/dgj-v51-recruitment.js" "$BACKUP/"
cp -a "$ASSETS/dgj-v51-recruitment.css" "$BACKUP/"
cp -a "$PUBLIC/index.html" "$BACKUP/"
echo "Backup: $BACKUP"

echo "5/9 ATOMIC V56 INSTALL"
install_atomic(){
  local src="$1"
  local dst="$2"
  local mode="${3:-0644}"
  local tmp="${dst}.v56.$$"
  install -m "$mode" "$src" "$tmp"
  mv -f "$tmp" "$dst"
}
MUTATED=1
install_atomic "$PAYLOAD/dist/dgj-v51-recruitment.cjs" "$DIST/dgj-v51-recruitment.cjs"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-employer.js" "$ASSETS/dgj-v51-employer.js"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.js" "$ASSETS/dgj-v51-recruitment.js"
install_atomic "$PAYLOAD/dist/public/assets/dgj-v51-recruitment.css" "$ASSETS/dgj-v51-recruitment.css"
install_atomic "$PAYLOAD/dist/public/index.html" "$PUBLIC/index.html"
[ "$(sha "$DIST/dgj-v51-recruitment.cjs")" = "$NEWREC" ] || fail "V56 backend hash mismatch"
[ "$(sha "$ASSETS/dgj-v51-employer.js")" = "$NEWEMP" ] || fail "V56 Employer JS hash mismatch"
[ "$(sha "$ASSETS/dgj-v51-recruitment.js")" = "$NEWJS" ] || fail "V56 recruitment JS hash mismatch"
[ "$(sha "$ASSETS/dgj-v51-recruitment.css")" = "$NEWCSS" ] || fail "V56 CSS hash mismatch"
[ "$(sha "$PUBLIC/index.html")" = "$NEWIDX" ] || fail "V56 index hash mismatch"
echo "PASS: five reviewed V56 files installed."

echo "6/9 PM2 RELOAD + BACKEND/SCHEMA HEALTH"
pm2 reload devglobaljobs --update-env
READY=0
for i in $(seq 1 30); do
  if curl -fsS --max-time 5 http://127.0.0.1:8080/api/v56/config -o /tmp/dgj-v56-config.json 2>/dev/null; then READY=1; echo "PASS: application ready after reload (attempt $i/30)."; break; fi
  sleep 1
done
[ "$READY" = 1 ] || fail "V56 API did not become ready"
python3 - <<'PY2'
import json
x=json.load(open('/tmp/dgj-v56-config.json'))
assert x.get('version')=='56.0.0',x
assert x.get('profileMinimum')==80,x
assert x.get('candidateConfirmationEmail') is True,x
assert x.get('weeklyAudienceRule')=='employer-precedence',x
assert set(x.get('profileCvFormats') or [])=={'british','europass','middle-east','new-zealand'},x
PY2
CODE=$(curl -sS -o /tmp/dgj-v56-ready-unauth -w '%{http_code}' --max-time 10 http://127.0.0.1:8080/api/v56/candidate/profile-readiness || true)
[ "$CODE" = 401 ] || fail "Profile readiness API must require candidate authentication (got $CODE)"
echo "PASS: V56 schema, profile gate API and email segmentation module loaded."

echo "7/9 ORIGIN FRONTEND CONTRACT"
TMP="$(mktemp -d)"
curl -fsS --max-time 20 http://127.0.0.1:8080/ -o "$TMP/home" || fail "origin home failed"
grep -Fq '/assets/dgj-v51-employer.js?v=56.0.0' "$TMP/home" || fail "V56 Employer JS reference missing"
grep -Fq '/assets/dgj-v51-recruitment.js?v=56.0.0' "$TMP/home" || fail "V56 recruitment JS reference missing"
grep -Fq '/assets/dgj-v51-recruitment.css?v=56.0.0' "$TMP/home" || fail "V56 CSS reference missing"
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.js?v=56.0.0' -o "$TMP/rec" || fail "origin V56 recruitment JS failed"
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-employer.js?v=56.0.0' -o "$TMP/emp" || fail "origin V56 Employer JS failed"
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.css?v=56.0.0' -o "$TMP/css" || fail "origin V56 CSS failed"
[ "$(sha "$TMP/rec")" = "$NEWJS" ] || fail "origin recruitment JS bytes mismatch"
[ "$(sha "$TMP/emp")" = "$NEWEMP" ] || fail "origin Employer JS bytes mismatch"
[ "$(sha "$TMP/css")" = "$NEWCSS" ] || fail "origin CSS bytes mismatch"
rm -rf "$TMP"
echo "PASS: origin serves V56 profile-quality and dual-CV Easy Apply assets."

echo "8/9 PROTECTED BYTE CHECK AFTER RELOAD"
[ "$(sha "$DIST/index.cjs")" = "$SERVER" ] || fail "main runtime changed"
[ "$(sha "$DIST/dgj-v45-commercial.cjs")" = "$V45B" ] || fail "V45 backend changed"
[ "$(sha "$DIST/dgj-v46-employer.cjs")" = "$V46B" ] || fail "V46 backend changed"
[ "$(sha "$ASSETS/dgj-v49-premium.js")" = "$V55V49" ] || fail "V55 premium JS changed"
[ "$(sha "$ASSETS/dgj-v45-commercial.js")" = "$V45UI" ] || fail "V45 UI changed"
[ "$(sha "$ASSETS/index-DGJ45auth-v43-youth.js")" = "$YOUTH" ] || fail "Youth changed"
[ "$(sha "$PUBLIC/dgj-google-jobs-v27.js")" = "$GOOGLE" ] || fail "Google Jobs changed"
[ "$(sha "$PUBLIC/devglobaljobs-social-share.png")" = "$SOCIAL" ] || fail "social image changed"
[ "$(sha "$PUBLIC/brand-contract.json")" = "$CONTRACT" ] || fail "brand contract changed"
[ "$(sha "$PUBLIC/sw.js")" = "$SW" ] || fail "service worker changed"
echo "PASS: V55 zero-flash Employer core, V45 commercial and protected SEO/PWA architecture preserved."

echo "9/9 FINAL"
MUTATED=0; trap - EXIT
echo "============================================================"
echo "SUCCESS: V56 CANDIDATE QUALITY + PROFILE CV EASY APPLY IS LIVE"
echo "============================================================"
echo "✓ Employers receive employer weekly audience only; same-email job-seeker weekly audience is suppressed"
echo "✓ Candidate Easy Apply requires server-verified 80% profile completion"
echo "✓ Candidate sees one Easy Apply button, then Profile CV or Uploaded CV"
echo "✓ Profile CV offers British, Europass, Middle East and New Zealand formats"
echo "✓ Selected Profile CV is generated from the candidate profile and stored privately with the application"
echo "✓ Employer sees CV source/format and profile quality in Applications"
echo "✓ Candidate receives premium position-specific application confirmation email"
echo "✓ Failed candidate confirmation emails are retried by the existing recruitment lifecycle"
echo "✓ Email Easy Apply remains non-withdrawable through DGJ"
echo "✓ V51 ATS/180-day retention and V55 zero-flash/performance architecture preserved"
echo "✓ V45 payments/Boost, Google Jobs, sitemap architecture, Youth, social, brand and PWA protected"
echo "Rollback backup: $BACKUP"
